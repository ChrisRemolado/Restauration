package controller;

/*
 * This software uses an external library "BiometricSDK" found online 
 * at https://sourceforge.net/projects/biometricsdk/
 */

import java.awt.image.BufferedImage;
import java.io.*;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.CFingerPrint;
import model.DialogBoxHelper;
import model.MySqlManager;

public class ClockInTimeController {

	private CFingerPrint m_finger1 = new CFingerPrint();
	private CFingerPrint m_finger2 = new CFingerPrint();
	private double finger1[] = new double[m_finger1.FP_TEMPLATE_MAX_SIZE];
	private double finger2[] = new double[m_finger2.FP_TEMPLATE_MAX_SIZE];
	private static Stage stage;
	private MySqlManager mysql;
	private String message;

	@FXML
	private ImageView sample_print,stored_print;
	@FXML
	private TextArea timeIO;
	@FXML
	private TextField empID;

	public void start(Stage mainStage) {
		stage = mainStage;
		mysql = MySqlManager.getInstance();
	}

	public void clockIn() throws InterruptedException, IOException {

		// Query data base and pass the ID number entered by employee
		String idNum = empID.getText();

		if(idNum.isEmpty()) {
			DialogBoxHelper.emptyFieldException();
			return;
		}
		
		timeIO.setText(toStringCredentials(mysql
				.getCredentials(idNum)));
		// Get image from DBMS
		stored_print.setImage(mysql.getUserBiometricPrint(idNum));

		// Get image from employee clocking
		sample_print.setImage(uploadImage());
		
		// Compare for authentication.
		//m_finger1.Match(finger1 , finger2,65,false);
		message = "Clock in";
	}

	public void clockOut() throws IOException {
		
		String idNum = empID.getText();

		if(idNum.isEmpty()) {
			DialogBoxHelper.emptyFieldException();
			return;
		}

		timeIO.setText(toStringCredentials(mysql
				.getCredentials(idNum)));
		
		// Get image from DBMS
		stored_print.setImage(mysql.getUserBiometricPrint(idNum));

		// Get image from employee clocking
		sample_print.setImage(uploadImage());
		
		// Compare for authentication.
		//m_finger1.Match(finger1 , finger2,65,false);
		message = "Clock out";
	}
	
	public void accept() {
		timeIO.setText(message+" succesful.");
		stored_print.setImage(null);
		sample_print.setImage(null);
		empID.setText("");
	}

	public void exit() throws IOException {

		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/view/hostpanel.fxml"));
		AnchorPane root = (AnchorPane)loader.load();


		HostpanelController userController = 
				loader.getController();
		userController.start(stage);

		Scene scene = new Scene(root,600,600);
		stage.setScene(scene);
		stage.show();
	}

	private String toStringCredentials(ArrayList<String> list) {
		return "Employee name: "+list.get(0)+
				"\nTitle: "+list.get(1)+
				"\nID: "+list.get(2)+
				"\nPLACE YOUR FINGER NOW PLEASE...";
	}

	private Image uploadImage() throws IOException {
		
		BufferedImage bi = null;
		FileChooser fc = new FileChooser();
		File file = fc.showOpenDialog(null);
		
		if(file != null) 
			bi = ImageIO.read(new File(file.getAbsolutePath()));
		
		/*
			to save a picture in db
			mysql.addBiometric(file,"123");
		*/
		return SwingFXUtils.toFXImage(bi, null);// Returns an image
	}
}
/*

private boolean matchMessage() {

Alert alert = new Alert(AlertType.INFORMATION);
alert.setTitle("Match %");
alert.setHeaderText(null);
alert.setContentText(Double.toString(m_finger1.Match(finger1 , finger2,65,false)));
alert.showAndWait();
return true;
}

private void errorMessage() {

Alert alert = new Alert(AlertType.INFORMATION);
alert.setTitle("Error Message");
alert.setHeaderText(null);
alert.setContentText("No match! try again");

alert.showAndWait();
}

 */