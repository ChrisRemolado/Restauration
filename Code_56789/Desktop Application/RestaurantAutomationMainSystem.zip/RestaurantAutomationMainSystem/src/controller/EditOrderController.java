package controller;

import javafx.stage.Stage;

public class EditOrderController {
	private static Stage stage;

	public void start(Stage mainStage) {
		stage = mainStage;
	}
}
